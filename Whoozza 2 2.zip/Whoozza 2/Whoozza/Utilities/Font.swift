//
//  Font.swift
//  Wooza
//
//  Created by Sunith on 26/10/21.
//

import Foundation
import UIKit

enum DMSans: String, Font {
    case regular = "DMSans-Regular"
    case boldItalic = "DMSans-BoldItalic"
    case italic = "DMSans-Italic"
    case medium = "DMSans-Medium"
    case mediumItalic = "DMSans-MediumItalic"
    case bold = "DMSans-Bold"
}

protocol Font {
    func of(size: CGFloat) -> UIFont
    func of(textStyle: UIFont.TextStyle, defaultSize: CGFloat, maxSize: CGFloat?) -> UIFont
}

extension Font where Self: RawRepresentable, Self.RawValue == String {
    func of(size: CGFloat) -> UIFont {
        UIFont(name: rawValue, size: size) ?? UIFont.systemFont(ofSize: 16)
    }
    func of(textStyle: UIFont.TextStyle, defaultSize: CGFloat, maxSize: CGFloat? = nil) -> UIFont {
        let font = of(size: defaultSize)
        let fontMetrics = UIFontMetrics(forTextStyle: textStyle)
        if let maxSize = maxSize {
            return fontMetrics.scaledFont(for: font, maximumPointSize: maxSize)
        } else {
            return fontMetrics.scaledFont(for: font)
        }
    }
}
