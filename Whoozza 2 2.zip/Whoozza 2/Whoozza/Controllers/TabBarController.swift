//
//  TLTabBarController.swift
//  WhoozaNavigationController
//
//  Created by Nandeesh on 09/10/21.
//

import UIKit

class TabBarController: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.configureTabs()
    }
    
    private func configureTabs() {
        let homeStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let homeViewController: UIViewController = homeStoryboard.instantiateViewController(withIdentifier: "HomeViewController")
        let homeIcon = UITabBarItem(title: "", image: UIImage(named: "Home"), selectedImage: UIImage(named: "Home"))
        homeViewController.tabBarItem = homeIcon
        
        
        let searchStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let searchViewController: UIViewController = searchStoryboard.instantiateViewController(withIdentifier: "SearchViewController")
        let searchIcon = UITabBarItem(title: "", image: UIImage(named: "Search"), selectedImage: UIImage(named: ""))
        searchViewController.tabBarItem = searchIcon
        
        
        let profileStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let profileViewController: UIViewController = profileStoryboard.instantiateViewController(withIdentifier: "ProfilePageViewController")
        let profileIcon = UITabBarItem(title: "", image: UIImage(named: "ProfileIcon"), selectedImage: UIImage(named: ""))
        profileViewController.tabBarItem = profileIcon
        
        
        let editProfileStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let editProfileViewController: UIViewController = editProfileStoryboard.instantiateViewController(withIdentifier: "EditProfileViewController")
        let editIcon = UITabBarItem(title: "", image: UIImage(named: "EditProfile"), selectedImage: UIImage(named: ""))
        editProfileViewController.tabBarItem = editIcon
        
        
        let menuStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let menuScreenViewController: UIViewController = menuStoryboard.instantiateViewController(withIdentifier: "MenuScreenViewController")
        let menuIcon = UITabBarItem(title: "", image: UIImage(named: "MenuIcon"), selectedImage: UIImage(named: "FleetTabSelectedIcon"))
        menuScreenViewController.tabBarItem = menuIcon
        
        
        self.viewControllers = [homeViewController, searchViewController, profileViewController, editProfileViewController,menuScreenViewController]
        
    }
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        true
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
    }
}
