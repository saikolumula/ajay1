//
//  MenuScreenViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit

class MenuScreenViewController: UIViewController {
    
    //:-IBOUTLETS
    
    @IBOutlet weak var closeButton: UIButton!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var inviteFrndsView: UIView!
    @IBOutlet weak var myAccountView: UIView!
    @IBOutlet weak var notificationView: UIView!
    @IBOutlet weak var helpCenterView: UIView!
    @IBOutlet weak var contactView: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI(){
        
        inviteFrndsView.layer.cornerRadius = 20
        myAccountView.layer.cornerRadius = 5
        notificationView.layer.cornerRadius = 5
        helpCenterView.layer.cornerRadius = 5
        
        closeButton.layer.borderWidth = 1
        closeButton.layer.masksToBounds = false
        closeButton.layer.borderColor = UIColor.clear.cgColor
        closeButton.layer.cornerRadius = closeButton.frame.height/2
        closeButton.clipsToBounds = true
        
        cameraButton.layer.borderWidth = 1
        cameraButton.layer.masksToBounds = false
        cameraButton.layer.borderColor = UIColor.clear.cgColor
        cameraButton.layer.cornerRadius = closeButton.frame.height/2
        cameraButton.clipsToBounds = true
        
        contactView.layer.borderWidth = 1
        contactView.layer.masksToBounds = false
        contactView.layer.borderColor = UIColor.clear.cgColor
        contactView.layer.cornerRadius = contactView.frame.height/2
        contactView.clipsToBounds = true
    }
    
    //:- IBACTIONS
    
    @IBAction func myContactsUserAction(_ sender: Any) {
        
    }
    
    @IBAction func notificationAction(_ sender: Any) {
        
    }
    
    @IBAction func helpCenterAction(_ sender: Any) {
        
    }
    @IBAction func myProfileAction(_ sender: Any) {
        
    }
}
