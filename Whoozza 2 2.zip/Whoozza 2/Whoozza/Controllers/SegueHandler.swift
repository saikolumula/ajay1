//
//  SegueHandler.swift
//  WhoozaNavigationController
//
//  Created by Sunith on 25/10/21.
//

import Foundation
import UIKit

protocol SegueHandler {

    associatedtype ViewControllerSegue: RawRepresentable
    func segueIdentifierCase(for segue: UIStoryboardSegue) -> ViewControllerSegue

}

extension SegueHandler where Self: UIViewController, ViewControllerSegue.RawValue == String {

    func segueIdentifierCase(for segue: UIStoryboardSegue) -> ViewControllerSegue {
        guard let identifier = segue.identifier,
            let identifierCase = ViewControllerSegue(rawValue: identifier) else {
            fatalError("Could not map segue identifier -- (segue.identifier) -- to segue case")
        }
        return identifierCase
    }

}
