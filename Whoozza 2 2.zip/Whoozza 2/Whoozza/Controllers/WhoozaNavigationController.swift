//
//  WhoozaNavigationController.swift
//  WhoozaNavigationController
//
//  Created by Sunith on 25/10/21.
//

import UIKit

class WhoozaNavigationController: UINavigationController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationBar.titleTextAttributes = [
            .font: DMSans.medium.of(size: 23)
        ]
        removeNavigationBarSeperator()
    }
    func removeNavigationBarSeperator() {
        navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationBar.shadowImage = UIImage()
        navigationBar.barTintColor = ColorPalette.backgroundGray.uiColor
        navigationBar.tintColor = .black
    }
}

extension WhoozaNavigationController: SegueHandler {
    enum ViewControllerSegue: String {
       case showOnboarding
       case unnamed = ""
    }
}
