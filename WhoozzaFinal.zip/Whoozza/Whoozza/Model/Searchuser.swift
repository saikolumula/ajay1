/* 
Copyright (c) 2022 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Searchuser : Codable {
	let success : Bool?
	let data : [SearchuserData]?

	enum CodingKeys: String, CodingKey {

		case success = "success"
		case data = "data"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		success = try values.decodeIfPresent(Bool.self, forKey: .success)
		data = try values.decodeIfPresent([SearchuserData].self, forKey: .data)
	}

}
import Foundation
struct SearchuserData : Codable {
    let id : String?
    let user_id : String?
    let title : String?
    let video : String?
    let like_cnt : String?
    let status : String?
    let created : String?
    let show_like_btn : Int?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case user_id = "user_id"
        case title = "title"
        case video = "video"
        case like_cnt = "like_cnt"
        case status = "status"
        case created = "created"
        case show_like_btn = "show_like_btn"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(String.self, forKey: .id)
        user_id = try values.decodeIfPresent(String.self, forKey: .user_id)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        video = try values.decodeIfPresent(String.self, forKey: .video)
        like_cnt = try values.decodeIfPresent(String.self, forKey: .like_cnt)
        status = try values.decodeIfPresent(String.self, forKey: .status)
        created = try values.decodeIfPresent(String.self, forKey: .created)
        show_like_btn = try values.decodeIfPresent(Int.self, forKey: .show_like_btn)
    }
}
typealias SearchTotalData = [SearchuserData]
