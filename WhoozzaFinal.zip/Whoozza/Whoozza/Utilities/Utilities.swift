//
//  Utilities.swift
//  Whoozza
//
//  Created by Sandip on 08/03/22.
//

import UIKit

class Utilities: NSObject {
    
    class func getSafeAreaTopPadding() -> CGFloat {
        var topPadding: CGFloat = 0
        if #available(iOS 11.0, *) {
            topPadding = (appDelegate.window?.safeAreaInsets.top)!
        }
        return topPadding
    }
    
    class func getSafeAreaBottomPadding() -> CGFloat {
        var bottomPadding: CGFloat = 0
        if #available(iOS 11.0, *) {
            bottomPadding = (appDelegate.window?.safeAreaInsets.bottom)!
        }
        return bottomPadding
    }
}
extension UIViewController {
    
    func showAlert(title: String, message: String, shouldMoveBack: Bool) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.destructive, handler: { _ in
            if shouldMoveBack {
                _ = self.navigationController?.popViewController(animated: true)
            }
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func showAlertFleet(title: String, message: String, shouldMoveBack: Bool) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.destructive, handler: { _ in
            if shouldMoveBack {
                _ = self.navigationController?.pushViewController(alert, animated: true)
            }
            
        }))
        self.present(alert, animated: true, completion: nil)
    }
    func showAlertTrip(title: String, message: String,shouldMoveBack:Bool) {
        
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.destructive, handler: { _ in
            self.present(alert, animated: true, completion: nil)
        }))
        self.present(alert, animated: true, completion: nil)
    }
}
