//
//  RegistrationViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit
import GoogleSignIn
import FBSDKLoginKit


class RegistrationViewController: UIViewController {
    
    //IBOUTLETS : -
    
    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var faceBookButton: FBLoginButton!
    @IBOutlet weak var googleSignIn: UIButton!
    @IBOutlet weak var continueWithGoogleView: UIView!
    @IBOutlet weak var continueWithFacebookView: UIView!
    
    var repository = HomeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI(){
        signUpButton.layer.cornerRadius = 20
        continueWithGoogleView.layer.cornerRadius = 5
        continueWithFacebookView.layer.cornerRadius = 5
        faceBookButton.layer.backgroundColor = #colorLiteral(red: 0.1215686277, green: 0.01176470611, blue: 0.4235294163, alpha: 1)
        userNameTextfield.becomeFirstResponder()
        emailTextfield.becomeFirstResponder()
        passwordTextfield.becomeFirstResponder()
    }
    
    func loadData() {
        let params:[String:Any] = ["username":userNameTextfield.text!,
                                   "password":passwordTextfield.text!,
                                   "first_name":"sai",
                                   "last_name":"nath",
                                   "email":emailTextfield.text!,
                                   "mobile":"6303671292"]
        
        repository.executeRegistrationApi(params: params){ (result: Result<SignInData, Error>) in
            
            switch result {
            case .success:
                let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
                self.navigationController?.pushViewController(vc, animated: true)
            case .failure:
                print("error")
            }
        }
    }
    
    //IB ACTIONS :-
    
    @IBAction func continueWithGoogleAction(_ sender: Any) {
        GIDSignIn.sharedInstance.signIn(with: signInConfig, presenting: self) { user, error in
           guard error == nil else { return }

         }
    }
    
    @IBAction func continueWithFacebookAction(_ sender: Any) {
        if let token = AccessToken.current,
           !token.isExpired {
            // User is logged in, do work such as go to next view controller.
        }else{
            faceBookButton.permissions = ["public_profile", "email"]
            faceBookButton.delegate = self
        }
    }
    
    @IBAction func signInAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func signUpAction(_ sender: Any) {
        if userNameTextfield.text != "" && emailTextfield.text != "" && passwordTextfield.text != ""{
            loadData()
        }else{
            showAlert(title: "Alert", message: "Please fill all the details", shouldMoveBack: false)
        }
    }
}

extension RegistrationViewController:LoginButtonDelegate{
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        let token = result?.token?.tokenString
        let request = FBSDKLoginKit.GraphRequest(graphPath: "me", parameters: ["fields":"email,name,password"],tokenString: token,version: nil,httpMethod: .get)
        request.start { NSURLConnection, result, error in
            print("\(result)")
        }
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        print("log out")
    }
}
