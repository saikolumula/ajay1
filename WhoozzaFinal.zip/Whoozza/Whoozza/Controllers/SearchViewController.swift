//
//  SearchViewController.swift
//  Whoozza
//
//  Created by sainath on 11/03/22.
//

import UIKit
import AVKit

class SearchViewController: UIViewController {
    
    //IBOUTLETS : -
    
    @IBOutlet weak var searchCollectionView: UICollectionView!
    @IBOutlet weak var searchButton: UISearchBar!
    
    var likeID:Int = 0
    var userID:String = ""
    let repository = HomeViewModel()
    var followUserData1:FollowUserData?
    var selectUserModelData = SelectVideoViewModel()
    var searchLists = [SearchuserData]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        self.searchCollectionView.delegate = self
        self.searchCollectionView.dataSource = self
        self.searchCollectionView.alwaysBounceVertical = true
        self.searchCollectionView.backgroundColor = .white
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // API CALL: -
    
    func loadData() {
        let queryParams : [String:Any] = [:]
        self.selectUserModelData.executeSearchVideoApi(params: queryParams)
        self.selectUserModelData.SearchToController = {
            if let search = self.selectUserModelData.searchUserClickData {
                self.searchLists = search
                self.searchCollectionView.reloadData()
            }
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let visibleCells = self.searchCollectionView.indexPathsForVisibleItems
            .sorted { top, bottom -> Bool in
                return top.section < bottom.section || top.row < bottom.row
            }.compactMap { indexPath -> UICollectionViewCell? in
                return self.searchCollectionView.cellForItem(at: indexPath)
            }
        let indexPaths = self.searchCollectionView.indexPathsForVisibleItems.sorted()
        let cellCount = visibleCells.count
        guard let firstCell = visibleCells.first as? SearchCell, let firstIndex = indexPaths.first else {return}
        checkVisibilityOfCell(cell: firstCell, indexPath: firstIndex)
        if cellCount == 1 {return}
        guard let lastCell = visibleCells.last as? SearchCell, let lastIndex = indexPaths.last else {return}
        checkVisibilityOfCell(cell: lastCell, indexPath: lastIndex)
    }
    
    func checkVisibilityOfCell(cell: SearchCell, indexPath: IndexPath) {
        if let cellRect = (searchCollectionView.layoutAttributesForItem(at: indexPath)?.frame) {
            let completelyVisible = searchCollectionView.bounds.contains(cellRect)
            if completelyVisible {()} else {cell.stopVideo()}
        }
    }
}

extension SearchViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    //:- DELEGATE AND DATASOURCE
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.searchLists.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchCell", for: indexPath) as? SearchCell {
            
            let videoURL = URL(string: searchLists[indexPath.row].video ?? "")
            likeID = searchLists[indexPath.row].show_like_btn ?? 0
            userID = searchLists[indexPath.row].user_id ?? ""
            cell.VideoLikesCount.text = searchLists[indexPath.row].like_cnt
            
            let player = AVPlayer(url: videoURL!)
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = cell.playVideoView.bounds
            cell.playVideoView.layer.addSublayer(playerLayer)
            player.play()
            
            var videoPlayer: AVPlayer? = nil

        
             let path = Bundle.main.path(forResource: searchLists[indexPath.row].video, ofType:"mp4")
               
            videoPlayer = AVPlayer(url: URL(fileURLWithPath: path ?? ""))
            videoPlayer?.playImmediately(atRate: 1)
            cell.playerView.player = videoPlayer
            
            return cell
        }
        fatalError("Could not dequeue cell")
    }
}

extension SearchViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.width/3 - 10), height: 150)
    }
}

extension SearchViewController:UISearchBarDelegate{
    // MARK: - Searchbar Delegate
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = nil
        searchBar.resignFirstResponder()
        searchBar.endEditing(true)
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if let videos = self.selectUserModelData.searchUserClickData {
            searchLists = searchText.isEmpty ? videos : videos.filter {
                $0.like_cnt?.range(of: searchText, options: .caseInsensitive) != nil ||
                $0.created?.range(of: searchText, options: .caseInsensitive) != nil ||
                $0.like_cnt?.range(of: searchText, options: .caseInsensitive) != nil
            }
        }
        print(searchText)
        print("Filter Data \(searchLists)")
        searchCollectionView.reloadData()
    }
}
