//
//  LoginViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit
import GoogleSignIn
import FBSDKLoginKit

class LoginViewController: WoozaViewController {
    
    //IBOUTLETS : -
    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var continueWithGoogleView: UIView!
    @IBOutlet weak var continueWithFacebookView: UIView!
    @IBOutlet weak var faceBookButton: FBLoginButton!
    
    var repository = HomeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    func setupUI(){
        
        loginButton.layer.cornerRadius = 20
        continueWithGoogleView.layer.cornerRadius = 5
        continueWithFacebookView.layer.cornerRadius = 5
        userNameTextfield.becomeFirstResponder()
        emailTextfield.becomeFirstResponder()
        
    }
    
    func loadData() {
        
        let params:[String:Any] = ["username":userNameTextfield.text!,
                                   "password":emailTextfield.text!]
        
        repository.executeLoginApi(params: params){ (result: Result<LoginData, Error>) in
            switch result {
            case .success:
                print("error")
            case .failure:
                print("error")
            }
        }
    }
    
    //:- IB ACTIONS
    
    @IBAction func continueWithGoogleAction(_ sender: Any) {
        GIDSignIn.sharedInstance.signIn(with: signInConfig, presenting: self) { user, error in
            guard error == nil else { return }
            
        }
    }
    
    @IBAction func continueWithFacebookAction(_ sender: Any) {
        if let token = AccessToken.current,
           !token.isExpired {
            // User is logged in, do work such as go to next view controller.
        }else{
            faceBookButton.permissions = ["public_profile", "email"]
            faceBookButton.delegate = self
        }
    }
    
    @IBAction func createAction(_ sender: Any) {
    }
    
    @IBAction func loginAction(_ sender: Any) {
        if userNameTextfield.text != "" && emailTextfield.text != "" {
            loadData()
            self.showTabBar()
        }else{
            showAlert(title: "Alert", message: "Please fill all the details", shouldMoveBack: false)
        }
    }
}

extension LoginViewController:LoginButtonDelegate{
    
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        let token = result?.token?.tokenString
        let request = FBSDKLoginKit.GraphRequest(graphPath: "me", parameters: ["fields":"email,name,password"],tokenString: token,version: nil,httpMethod: .get)
        request.start { NSURLConnection, result, error in
            print("\(result)")
        }
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        print("log out")
    }
}
