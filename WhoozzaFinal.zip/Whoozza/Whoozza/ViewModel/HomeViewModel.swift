//
//  File.swift
//  Whoozza
//
//  Created by sainath on 09/03/22.
//

import Foundation
class HomeViewModel{
    
    var homePageUrls = [HomeModel]()
    var signInData:SignInData?
    var loginData:LoginData?
    var likeVideoUrl:VideoLiked?
    var followUserData:FollowUserData?
    var addVideoUserData:FollowUserData?
    
    func executeHomeVideoApi(params:[String:Any], completion:@escaping (Result<[HomeModel],Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.homeVideosUrl.path, method: .get, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<[HomeModel]>, Error>) in
            switch result {
            case .success(let data):
                self.homePageUrls.append(contentsOf: data.data ?? [])
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    func executeLikeVideoApi(params:[String:Any], completion:@escaping (Result<VideoLiked,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.videoLiked.path, method: .get, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<VideoLiked>, Error>) in
            switch result {
            case .success(let data):                
                self.likeVideoUrl = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func executeLoginApi(params:[String:Any], completion:@escaping (Result<LoginData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.Login.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<LoginData>, Error>) in
            switch result {
            case .success(let data):
                self.loginData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func executeRegistrationApi(params:[String:Any], completion:@escaping (Result<SignInData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.Registration.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<SignInData>, Error>) in
            switch result {
            case .success(let data):
                self.signInData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func executeAddVideoOfUserApi(params:[String:Any], completion:@escaping (Result<FollowUserData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.addVideo.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<FollowUserData>, Error>) in
            switch result {
            case .success(let data):
                self.addVideoUserData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }

    
    func executeFollowUserApi(params:[String:Any], completion:@escaping (Result<FollowUserData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.followUser.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<FollowUserData>, Error>) in
            switch result {
            case .success(let data):
                self.followUserData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }    
}
class SelectVideoViewModel: NSObject {
    var searchUserData = [SearchuserData]()
    
    private(set) var searchUserClickData: SearchTotalData?  {
        didSet {
            self.SearchToController()
        }
    }
    
    var SearchToController : (() -> ()) = {}
    
    func executeSearchVideoApi(params: [String:Any]) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.searchVideo.path, method: .get).executeQuery {  (result: Result<WhoozaResult<SearchTotalData>, Error>) in
                switch result {
                    case .success(let data):
                    self.searchUserClickData = data.data
                    case .failure(let error):
                        print(error)
            }
        }
    }
    
//    func executeSearchVideoApi(params:[String:Any], completion:@escaping (Result<[SearchuserData],Error>) -> Void) {
//        NetworkManager(data: [:], params: params, path: WebServiceAPI.searchVideo.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<[SearchuserData]>, Error>) in
//            switch result {
//            case .success(let data):
//                self.searchUserData = data.data ?? []
//                if let trucksData = data.data {
//                    completion(.success(trucksData))
//                }
//            case .failure(let error):
//                DispatchQueue.main.async {
//                    completion(.failure(error))
//                }
//            }
//        }
//    }
}
