//
//  TLRootViewController.swift
//  WhoozaNavigationController
//
//  Created by Nandeesh on 09/10/21.
//

import UIKit

class TLRootViewController: UIViewController {

    var operationsTabBarController: TabBarController?
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    private func loadOperationsScreens() {
        // Please make sure the storyboard id and the view controller class have the same string name
        let rootStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        self.operationsTabBarController = rootStoryboard.instantiateViewController(withIdentifier: "TabBarController") as? TabBarController
    }
    
    private func unloadOperationsScreens() {
        self.operationsTabBarController?.view.removeFromSuperview()
        self.operationsTabBarController = nil
    }
    
    private func presentOperationsFlow() {
        self.loadOperationsScreens()
        if let operationsTabBarController = self.operationsTabBarController {
            self.view.addSubview(operationsTabBarController.view)
        }
    }
}
