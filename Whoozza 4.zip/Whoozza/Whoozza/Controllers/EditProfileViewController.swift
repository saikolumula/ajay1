//
//  EditProfileViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit
import Photos
import CropViewController

class EditProfileViewController: UIViewController,UITextFieldDelegate {
    
    //:-IBOUTLETS
    
    @IBOutlet weak var firstNameView: UIView!
    @IBOutlet weak var lastNameView: UIView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var mobileNumber: UIView!
    @IBOutlet weak var editProfileIMageAction: UIButton!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var firstNameTextfield: UITextField!
    @IBOutlet weak var lastNameTextfield: UITextField!
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var mobileNumberTextfield: UITextField!
    
    var uploadDocImageView = UIImage()
    var croppedImageView : ((UIImage) -> Void)? = nil
    var shouldUploadImageView: Bool = true
    var userName:String?
    var password:String?
    var repository  = HomeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    // SETUPUI :-
    
    func setupUI(){
        
        firstNameView.layer.cornerRadius = 5
        lastNameView.layer.cornerRadius = 5
        emailView.layer.cornerRadius = 5
        mobileNumber.layer.cornerRadius = 5
        firstNameTextfield.becomeFirstResponder()
        emailTextfield.becomeFirstResponder()
        lastNameTextfield.becomeFirstResponder()
        mobileNumberTextfield.resignFirstResponder()
        firstNameTextfield.textColor = UIColor.white
        lastNameTextfield.textColor = UIColor.white
        emailTextfield.textColor = UIColor.white
        mobileNumberTextfield.textColor = UIColor.white
        
        firstNameTextfield.attributedPlaceholder = NSAttributedString(
            string: "First name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        lastNameTextfield.attributedPlaceholder = NSAttributedString(
            string: "Last name",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        emailTextfield.attributedPlaceholder = NSAttributedString(
            string: "Email",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        mobileNumberTextfield.attributedPlaceholder = NSAttributedString(
            string: "Phone number",
            attributes: [NSAttributedString.Key.foregroundColor: UIColor.white]
        )
        
    }
    
    func loadData() {
        let params:[String:Any] = ["username":userName,
                                   "password":password,
                                   "first_name":firstNameTextfield.text!,
                                   "last_name":lastNameTextfield.text!,
                                   "email":emailTextfield.text!,
                                   "mobile":mobileNumberTextfield.text!]
        repository.executeRegistrationApi(params: params){ (result: Result<SignInData, Error>) in
            switch result {
            case .success:
                self.navigationController?.popViewController(animated: true)
            case .failure:
                print("error")
            }
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        firstNameTextfield.textColor = UIColor.white
        emailTextfield.textColor = UIColor.white
        lastNameTextfield.textColor = UIColor.white
        mobileNumberTextfield.textColor = UIColor.white
    }
    
    //:-IBACTION
    
    @IBAction func saveAction(_ sender: Any) {
        loadData()
    }
    
    @IBAction func editProfileAction(_ sender: Any) {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerController.SourceType.camera
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        } else {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func editAccountAction(_ sender: Any) {
        
    }
}

extension EditProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate, CropViewControllerDelegate {
    // MARK: ImagePicker delegate
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        let imageKey = picker.allowsEditing ? UIImagePickerController.InfoKey.editedImage : UIImagePickerController.InfoKey.originalImage
        self.dismiss(animated: false) {
            if let image = info[imageKey] as? UIImage {
                let cropController = CropViewController(croppingStyle: CropViewCroppingStyle.default, image: image)
                cropController.delegate = self
                self.present(cropController, animated: true, completion: nil)
            } else {
                print("Something went wrong in  image")
            }
        }
    }
    
    func cropViewController(_ cropViewController: CropViewController, didFinishCancelled cancelled: Bool) {
        cropViewController.dismiss(animated: true, completion: {
        })
    }
    
    public func cropViewController(_ cropViewController: CropViewController, didCropToImage image: UIImage, withRect cropRect: CGRect, angle: Int) {
        cropViewController.dismiss(animated: false) {
            self.dismiss(animated: false) {
                print("Collect the images")
                self.uploadDocImageView = image
                self.croppedImageView!(image)
            }
        }
    }
}
