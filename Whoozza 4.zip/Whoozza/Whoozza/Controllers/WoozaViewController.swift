//
//  WoozaViewController.swift
//  Wooza
//
//  Created by Sunith on 25/10/21.
//

import UIKit

class WoozaViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func showTabBar() {
        if #available(iOS 13.0, *) {
            guard let keyWindow = UIApplication.shared.connectedScenes
                    .filter({$0.activationState == .foregroundActive})
                    .compactMap({$0 as? UIWindowScene})
                    .first?.windows
                    .filter({$0.isKeyWindow}).first else {return}
            
            let onboardingStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let initialViewController = onboardingStoryboard.instantiateViewController(withIdentifier: "TabBarController")
            keyWindow.rootViewController = WhoozaNavigationController(rootViewController: initialViewController)
            keyWindow.makeKeyAndVisible()
        } else {
            // Fallback on earlier versions
        }
        
    }
    func showAlert(viewController: UIViewController, title: String, message: String) {
        let alertController = UIAlertController()
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        alertController.title = title
        alertController.message = message
        viewController.present(alertController, animated: true, completion: nil)
    }
}
