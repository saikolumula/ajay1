//
//  ViewController.swift
//  Whoozza
//
//  Created by sainath on 07/03/22.
//

import Foundation
import UIKit
import AVKit
import AVFoundation
import MobileCoreServices
import Alamofire

class HomeViewController: UIViewController,UIImagePickerControllerDelegate,VideoPickerDelegate {
    
    //IBOUTLETS : -
    
    @IBOutlet weak var homeCollectionView: UICollectionView!
    
    var likeID:Int = 0
    var userID:String = ""
    var followUserId:String?
    var videoTitle:String?
    var videoID:String?
    var videoAndImageReview = UIImagePickerController()
//    var videoPicker = VideoPicker(presentationController: UIViewController, delegate: sembuf)
    
    var cameraConfig: CameraConfiguration!
    let imagePickerController = UIImagePickerController()
    
    var videoRecordingStarted: Bool = false {
        didSet{
            if videoRecordingStarted {
                cell.addIMageButton.backgroundColor = UIColor.red
            } else {
                cell.addIMageButton.backgroundColor = UIColor.white
            }
        }
    }
    
    
    let repository = HomeViewModel()
    let cell = HomeCell()
    
    var arrVideo : [URL] = []
    func didSelect(url: URL?) {
        if let y = url {
            // x was not nil, and its value is now stored in y
            arrVideo.append(url!)
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            self.loadData()
        }
        setupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func setupUI(){
        self.homeCollectionView.register(UINib(nibName: "HomeCell", bundle: nil), forCellWithReuseIdentifier: "HomeCell")
        self.homeCollectionView.delegate = self
        self.homeCollectionView.dataSource = self
        self.homeCollectionView.alwaysBounceVertical = true
        self.homeCollectionView.backgroundColor = .white
    }
    
    //API CALL : -
    
    func loadData() {
        repository.executeHomeVideoApi(params: [:]){ (result: Result<[HomeModel], Error>) in
            switch result {
            case .success:
                self.homeCollectionView.reloadData()
            case .failure:
                print("error")
            }
        }
    }
    
    func loadLikedData() {
        let params:[String:Any] = ["user_id":userID,"video_id":likeID,"action":videoID]
        repository.executeLikeVideoApi(params: params){ (result: Result<VideoLiked, Error>) in
            switch result {
            case .success:
                self.homeCollectionView.reloadData()
            case .failure:
                print("error")
            }
        }
    }
    
    func loadUserFollowData() {
        let params:[String:Any] = ["user_id":userID, "follow_user_id": followUserId]
        repository.executeFollowUserApi(params: params){ (result: Result<FollowUserData, Error>) in
            switch result {
            case .success:
                self.homeCollectionView.reloadData()
            case .failure:
                print("error")
            }
        }
    }
    
    public func imageFromVideo(url: URL, at time: TimeInterval, completion: @escaping (UIImage?) -> Void) {
        DispatchQueue.global(qos: .background).async {
            let asset = AVURLAsset(url: url)
            let assetIG = AVAssetImageGenerator(asset: asset)
            assetIG.appliesPreferredTrackTransform = true
            assetIG.apertureMode = AVAssetImageGenerator.ApertureMode.encodedPixels
            let cmTime = CMTime(seconds: time, preferredTimescale: 60)
            let thumbnailImageRef: CGImage
            do {
                thumbnailImageRef = try assetIG.copyCGImage(at: cmTime, actualTime: nil)
            } catch let error {
                print("Error: \(error)")
                return completion(nil)
            }
            DispatchQueue.main.async {
                completion(UIImage(cgImage: thumbnailImageRef))
            }
        }
    }
    

    func uplaodVideo(){
        let url = URL(string: "http://google.com")
        let header : HTTPHeaders = ["token": UserDefaults.standard.string(forKey: "Key") ?? ""]
        let parameter : [String: Any] = ["user_id":userID, "title": videoTitle,"video":""]
        
        AF.upload(multipartFormData: { (multipartFormData) in
            for (key, value) in parameter{
                multipartFormData.append(((value as Any) as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
            }
            let diceRoll = Int(arc4random_uniform(UInt32(100000)))
            do {
                let videoData = try Data(contentsOf: self.arrVideo[0])
                print("",videoData)
                multipartFormData.append(videoData, withName: "media_file", fileName: "album_file.mp4", mimeType: "mp4")
            } catch {
                debugPrint("Couldn't get Data from URL")
            }
        }, to: url!, method: .post, headers: header ).responseJSON(completionHandler: { (res) in
            print("This is the result", res.result)
            switch res.result {
            case .failure(let err):
                if let code = err.responseCode{
                    print("unable to upload the image and create a post ",code)
                    break
                }
            case .success(let sucess):
                self.dismiss(animated: false, completion: nil)
            }
        })
    }
    
    @IBAction func recordVideoButtonAction(_ sender: UIButton) {
//        self.videoPicker = VideoPicker(presentationController: self, delegate: self)
//        self.videoPicker.present(from: sender as! UIView)
        uplaodVideo()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let visibleCells = self.homeCollectionView.indexPathsForVisibleItems
            .sorted { top, bottom -> Bool in
                return top.section < bottom.section || top.row < bottom.row
            }.compactMap { indexPath -> UICollectionViewCell? in
                return self.homeCollectionView.cellForItem(at: indexPath)
            }
        let indexPaths = self.homeCollectionView.indexPathsForVisibleItems.sorted()
        let cellCount = visibleCells.count
        guard let firstCell = visibleCells.first as? HomeCell, let firstIndex = indexPaths.first else {return}
        checkVisibilityOfCell(cell: firstCell, indexPath: firstIndex)
        if cellCount == 1 {return}
        guard let lastCell = visibleCells.last as? HomeCell, let lastIndex = indexPaths.last else {return}
        checkVisibilityOfCell(cell: lastCell, indexPath: lastIndex)
    }
    
    func checkVisibilityOfCell(cell: HomeCell, indexPath: IndexPath) {
        if let cellRect = (homeCollectionView.layoutAttributesForItem(at: indexPath)?.frame) {
            let completelyVisible = homeCollectionView.bounds.contains(cellRect)
            if completelyVisible {()} else {cell.stopVideo()}
        }
    }
    
    @IBAction func profileButtonAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(identifier: "ProfilePageViewController") as! ProfilePageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func followUnfollowUserButtonAction(_ sender: UIButton) {
        loadUserFollowData()
    }
    
    @IBAction func videoLikedButtonAction(_ sender: UIButton) {
        loadLikedData()
    }
}

extension HomeViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    
    //:- DELEGATE AND DATASOURCE
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        repository.homePageUrls.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCell", for: indexPath) as? HomeCell {
            
            if cell.videLikeButton.isTouchInside == false{
                videoID = "like"
            }else{
                videoID = "unlike"
            }
                
            let videoURL = URL(string: repository.homePageUrls[indexPath.row].video)
            likeID = repository.homePageUrls[indexPath.row].showLikeBtn
            userID = repository.homePageUrls[indexPath.row].userID
            followUserId = repository.homePageUrls[indexPath.row].id
            videoTitle = repository.homePageUrls[indexPath.row].title
            cell.userLIkeLabel.text = repository.homePageUrls[indexPath.row].likeCnt
            cell.userCommentedLabel.text = "\(repository.homePageUrls[indexPath.row].showLikeBtn)"
            
            let player = AVPlayer(url: videoURL!)
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = cell.playerContainerView.bounds
            cell.playerContainerView.layer.addSublayer(playerLayer)
            player.play()
            
            cell.videLikeButton.addTarget(self, action: #selector(videoLikedButtonAction(_:)), for: .touchUpInside)
            
            cell.followButton.addTarget(self, action: #selector(followUnfollowUserButtonAction(_:)), for: .touchUpInside)
            
            cell.userProfileButton.addTarget(self, action: #selector(profileButtonAction(_:)), for: .touchUpInside)
            
            cell.addIMageButton.addTarget(self, action: #selector(recordVideoButtonAction(_:)), for: .touchUpInside)
                        
            return cell
        }
        fatalError("Could not dequeue cell")
    }
}

extension HomeViewController: UICollectionViewDelegateFlowLayout {
    
    //:- FLOWLAYOUT DELEGATE
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let width = ((collectionView.frame.width)) // 15 because of paddings
            print("cell width : \(width)")
        return CGSize(width: width, height: SCREEN_HEIGHT)
    }
}

//extension HomeViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
//
//    @IBAction func recordVideoButtonAction(_ sender: UIButton) {
//
//        self.videoPicker = VideoPicker(presentationController: self, delegate: self)
//        self.videoPicker.present(from: sender as! UIView)
//
//
//        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera){
//            print("camera available")
//            let imagePickerController = UIImagePickerController()
//            imagePickerController.delegate = self
//            imagePickerController.sourceType = .camera
//            imagePickerController.mediaTypes = [kUTTypeMovie as String]
//            imagePickerController.allowsEditing = false
//
////            self.loadUploadVideo(uplaodImage: image, imageKeyName: "document_front") { isSuccess, message  in
////                if isSuccess {
////                    print("Image upload success")
////                } else {
////                    self.showAlert(title: "Error", message: message ?? "", shouldMoveBack: false)
////                }
////            }
//            self.present(imagePickerController, animated: true, completion: nil)
//
//        }else{
//            print("camera unavailable")
//        }
//    }
//    func showImagePicker(){
//            let picker = UIImagePickerController()
//            picker.delegate = self
//            picker.mediaTypes = [kUTTypeMovie as String]
//            self.present(picker, animated: true, completion: nil)
//        }
//
//    private func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String:Any]) {
//
////        picker.dismiss(animated: true, completion: nil)
////        if let pickedVideo = info[UIImagePickerController.InfoKey.mediaType.rawValue] as? URL {
////                   print(pickedVideo)
////               }
//
//        picker.dismiss(animated: true, completion: nil)
//
//                    guard let videoUrl = info[UIImagePickerController.InfoKey.mediaType.rawValue] as? URL else {
//                        return
//                    }
//                    do {
//                        let data = try Data(contentsOf: videoUrl, options: .mappedIfSafe)
//                        print(data)
//        //  here you can see data bytes of selected video, this data object is upload to server by multipartFormData upload
//                    } catch  {
//
//                    }
//
//
//
//
//
//
//
////        dismiss(animated: true, completion: nil)
//
//
//
//
////        guard let mediaType = info[UIImagePickerController.InfoKey.mediaURL.rawValue] as? String,
////              let mediaType_ = (kUTTypeMovie as? String),
////              let url = info[UIImagePickerController.InfoKey.mediaURL.rawValue] as? URL,
////            UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(url.path)
////
////        else{
////            return
////        }
////        if let mediaType = info[UIImagePickerController.InfoKey.mediaType.rawValue] as? String {
////
////                    if mediaType == "public.movie" {
////                        print("Video Selected")
////                        let videoURL = info[UIImagePickerController.InfoKey.mediaURL.rawValue] as! URL
////
////                        selectedVideoURL = videoURL
////                        self.playVideo(videoURL)
////                    }
////                }
////                dismiss(animated: true, completion: nil)
//
//
////        self.loadUploadVideo(uplaodImage: mediaType, imageKeyName: "document_front") { isSuccess, message  in
////            if isSuccess {
////                print("Image upload success")
////            } else {
////                self.showAlert(title: "Error", message: message ?? "", shouldMoveBack: false)
////            }
////        }
//
//        //handle a movie capture
////        UISaveVideoAtPathToSavedPhotosAlbum(url.path, self, #selector(video(_videoPath: didFinishSavingWithError:contextInfo:)), nil)
//    }
//
//    @objc func video(_videoPath:String,didFinishSavingWithError error:Error?,contextInfo info:AnyObject){
//        let title  = (error == nil) ? "Successs":"Error"
//        let message  = (error == nil) ? "Video was saved":"Video Failed to save"
//
//        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//        present(alert, animated: true, completion: nil)
//    }
//}

