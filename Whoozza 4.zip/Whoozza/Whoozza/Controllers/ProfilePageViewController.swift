//
//  ProfilePageViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import Foundation
import UIKit
import AVKit
import AVFoundation

class ProfilePageViewController: UIViewController {
    
    //:- IBOUTLETS
    
    @IBOutlet weak var profileButton: UIButton!
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var userFollowingCount: UILabel!
    @IBOutlet weak var userFollowersCount: UILabel!
    @IBOutlet weak var userLikesCount: UILabel!
    @IBOutlet weak var editProfileButton: UIButton!
    @IBOutlet weak var messageButton: UIButton!
    @IBOutlet weak var userDropDownView: UIView!
    @IBOutlet weak var profileCollectionView: UICollectionView!
    
    var likeID:Int = 0
    var userID:String = ""
    let repository = HomeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadData()
        setupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        // call super of viewDidAppear
        super.viewDidAppear(animated)
    }
    
    func setupUI(){
        editProfileButton.layer.cornerRadius = 5
        messageButton.layer.cornerRadius = 5
        userDropDownView.layer.borderWidth = 1
        userDropDownView.layer.borderColor = UIColor.white.cgColor
        userDropDownView.layer.cornerRadius = 5
        self.profileCollectionView.delegate = self
        self.profileCollectionView.dataSource = self
        self.profileCollectionView.alwaysBounceVertical = true
        self.profileCollectionView.backgroundColor = .white
    }
    
    // API CALL : -
    
    func loadData(){
        repository.executeHomeVideoApi(params: [:]){ (result: Result<[HomeModel], Error>) in
            switch result {
            case .success:
                self.profileCollectionView.reloadData()
            case .failure:
                print("error")
            }
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let visibleCells = self.profileCollectionView.indexPathsForVisibleItems
            .sorted { top, bottom -> Bool in
                return top.section < bottom.section || top.row < bottom.row
            }.compactMap { indexPath -> UICollectionViewCell? in
                return self.profileCollectionView.cellForItem(at: indexPath)
            }
        let indexPaths = self.profileCollectionView.indexPathsForVisibleItems.sorted()
        let cellCount = visibleCells.count
        guard let firstCell = visibleCells.first as? ProfilePageCell, let firstIndex = indexPaths.first else {return}
        checkVisibilityOfCell(cell: firstCell, indexPath: firstIndex)
        if cellCount == 1 {return}
        guard let lastCell = visibleCells.last as? ProfilePageCell, let lastIndex = indexPaths.last else {return}
        checkVisibilityOfCell(cell: lastCell, indexPath: lastIndex)
    }
    
    func checkVisibilityOfCell(cell: ProfilePageCell, indexPath: IndexPath) {
        if let cellRect = (profileCollectionView.layoutAttributesForItem(at: indexPath)?.frame) {
            let completelyVisible = profileCollectionView.bounds.contains(cellRect)
            if completelyVisible {()} else {cell.stopVideo()}
        }
    }
    
    //:- IBACTIONS
    
    @IBAction func editProfileAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "EditProfileViewController") as! EditProfileViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func messageAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "MenuScreenViewController") as! MenuScreenViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ProfilePageViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    
    //:- DELEGATE AND DATASOURCE
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        repository.homePageUrls.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProfilePageCell", for: indexPath) as? ProfilePageCell {
            
            let videoURL = URL(string: repository.homePageUrls[indexPath.row].video)
            likeID = repository.homePageUrls[indexPath.row].showLikeBtn
            userID = repository.homePageUrls[indexPath.row].userID
            cell.VideoLikesCount.text = repository.homePageUrls[indexPath.row].likeCnt
            userLikesCount.text! = repository.homePageUrls[indexPath.row].likeCnt
            userFollowingCount.text! = "\(repository.homePageUrls[indexPath.row].showLikeBtn)"
            userFollowingCount.text! = "\(repository.homePageUrls[indexPath.row].showLikeBtn)"
            
            let player = AVPlayer(url: videoURL!)
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = cell.playVideoView.bounds
            cell.playVideoView.layer.addSublayer(playerLayer)
            player.play()
            
            return cell
        }
        fatalError("Could not dequeue cell")
    }
}

extension ProfilePageViewController: UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.frame.width/3 - 10), height: 100)
    }
}
