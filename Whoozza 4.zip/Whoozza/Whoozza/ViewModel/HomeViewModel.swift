//
//  File.swift
//  Whoozza
//
//  Created by sainath on 09/03/22.
//

import Foundation
import Alamofire

class HomeViewModel{
    
    var homePageUrls = [HomeModel]()
    var signInData:SignInData?
    var loginData:LoginData?
    var likeVideoUrl:VideoLiked?
    var followUserData:FollowUserData?
    var addVideoUserData:FollowUserData?

    
    func executeHomeVideoApi(params:[String:Any], completion:@escaping (Result<[HomeModel],Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.homeVideosUrl.path, method: .get, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<[HomeModel]>, Error>) in
            switch result {
            case .success(let data):
                self.homePageUrls.append(contentsOf: data.data ?? [])
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    func executeLikeVideoApi(params:[String:Any], completion:@escaping (Result<VideoLiked,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.videoLiked.path, method: .get, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<VideoLiked>, Error>) in
            switch result {
            case .success(let data):                
                self.likeVideoUrl = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func executeLoginApi(params:[String:Any], completion:@escaping (Result<LoginData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.Login.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<LoginData>, Error>) in
            switch result {
            case .success(let data):
                self.loginData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    func executeRegistrationApi(params:[String:Any], completion:@escaping (Result<SignInData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.Registration.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<SignInData>, Error>) in
            switch result {
            case .success(let data):
                self.signInData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
//    func executeAddVideoOfUserApi(params:[String:Any], completion:@escaping (Result<FollowUserData,Error>) -> Void) {
//        NetworkManager(data: [:], params: params, path: WebServiceAPI.addVideo.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<FollowUserData>, Error>) in
//            switch result {
//            case .success(let data):
//                self.addVideoUserData = data.data
//                if let trucksData = data.data {
//                    completion(.success(trucksData))
//                }
//            case .failure(let error):
//                DispatchQueue.main.async {
//                    completion(.failure(error))
//                }
//            }
//        }
//    }
//    func uploadVideo(videoUrl: URL) { // local video file path..
//            let timestamp = NSDate().timeIntervalSince1970 // just for some random name.
//
//            AF.upload(multipartFormData: { (multipartFormData) in
//                multipartFormData.append(videoUrl, withName: "image", fileName: "\(timestamp).mp4", mimeType: "\(timestamp)/mp4")
//            }, to: endPoint!  ).responseJSON { (response) in
//                debugPrint(response)
//            }
//        }
    
    
//    func imageData(params:[String:Any],videoUrl:URL,url:String){
//        let timestamp = NSDate().timeIntervalSince1970 // just for some random name.
//
//        AF.upload(multipartFormData: { (multipartFormData) in
//            multipartFormData.append(videoUrl, withName: "image", fileName: "\(timestamp).mp4", mimeType: "\(timestamp)/mp4")
//        }, to: url).responseJSON { (response) in
//            debugPrint(response)
//        }
//
//    }
//    func uploadVideo(videoUrl: URL,params:[String:Any]) { // local video file path..
//           let timestamp = NSDate().timeIntervalSince1970 // just for some random name.
//
//           AF.upload(multipartFormData: { (multipartFormData) in
//               multipartFormData.append(videoUrl, withName: "image", fileName: "\(timestamp).mp4", mimeType: "\(timestamp)/mp4")
//           }, to: "endPoint").responseJSON { (response) in
//               debugPrint(response)
//           }
//       }

    
    

//    func uploadImageData(params: [String: Any], imageName: String, keyName: String, imageFile: URL?, completion: @escaping (String?, Bool) -> Void) {
//        var headers = HTTPHeaders()
//        HeaderManager.shared.getHeaders().forEach({headers.add(name: $0.key, value: $0.value)})
//        AF.upload(multipartFormData: { multipartFormData in
//            if let img1MB = imageFile?.resizedTo1MB() {
//                for key in params.keys {
//                    let name = String(key)
//                    if let val = params[name] as? String{
//                        multipartFormData.append(val.data(using: .utf8)!, withName: name)
//                    }
//                }
//                multipartFormData.append(img1MB, withName: keyName, fileName: "\(imageName).png", mimeType: "image/png")
//            }
//        }, to: WebService.StagingServer.baseURL + WebServiceAPI.addVideo.path, method: .post, headers: headers) .responseJSON { (response) in
//            if let responseValue = response.value as? [String: Any]  {
//                if responseValue["message"] != nil {
//                    completion((responseValue["message"] as! String), (responseValue["errorCode"] as! Int == 200) ? true : false)
//                }
//            } else {
//                completion("Failed To Upload Image", false)
//            }
//        }
//    }
    
//    func apiCallWithMultipart(arrMedia:[TLPHAsset], completionHandler: @escaping (DataResponse<Any>) -> Void) {
//        
//        DispatchQueue.main.async {
//            AF.upload(multipartFormData: { (multipartFormData) in
//                // Add parameters
//                for (key, value) in self.parameters {
//                    let paramValue = "\(value)" as String
//                    multipartFormData.append(paramValue.data(using: String.Encoding.utf8, allowLossyConversion: false)!, withName: key as String)
//                }
//                
//                for media in arrMedia {
//                    if media.type == TLPHAsset.AssetType.video {
//                        media.phAsset?.requestContentEditingInput(with: PHContentEditingInputRequestOptions(), completionHandler: { (phContentEditingInput, [AnyHashable : Any]) in
//                            
//                            if let videoURL = (phContentEditingInput!.audiovisualAsset as? AVURLAsset)?.url {
//                                if videoURL.isFileURL {
//                                    
//                                    do {
//                                        let videoData = try Data(contentsOf: videoURL)
//                                        multipartFormData.append(videoData, withName: "album_file", fileName: "album_file", mimeType: "mp4")
//                                    } catch {
//                                        debugPrint("Couldn't get Data from URL: \(videoUrl): \(error)")
//                                    }
//                                    
//                                    
//                                    //print("\(videoURL)" + media.originalFileName!)
//                                    multipartFormData.append(videoURL, withName: "album_files[]", fileName: media.originalFileName ?? "Sample", mimeType: media.MIMEType(videoURL)!)
//                                    
//                                    //multipartFormData.append(videoURL, withName: "unicorn")
//                                }
//                            }
//                        })
//                    }
//                    else if media.type == TLPHAsset.AssetType.photo {
//                        let imageData = media.fullResolutionImage?.jpegData(compressionQuality: 1)
//                        if let data = imageData {
//                            multipartFormData.append(data, withName: "album_files[]", fileName: "\(Date().timeIntervalSince1970).jpg", mimeType: MimeType_jpg)
//                        }
//                    }
//                }
//                
//                
//                
//            }, to: self.url, usingThreshold: UInt64.init(), method: HTTPMethod.post, headers: self.headers, fileManager: FileManager.default)
//            
//            
//            .uploadProgress { progress in // main queue by default
//                print("Upload Progress: \(progress.fractionCompleted)")
//                print("Upload Estimated Time Remaining: \(String(describing: progress.estimatedTimeRemaining))")
//                print("Upload Total Unit count: \(progress.totalUnitCount)")
//                print("Upload Completed Unit Count: \(progress.completedUnitCount)")
//            }
//            
//            .responseJSON { (response) in
//                // Error Handle : https://github.com/Alamofire/Alamofire/blob/master/Documentation/Usage.md#response-handling
//                
//                //            #file          String   The name of the file in which it appears.
//                //            #line          Int      The line number on which it appears.
//                //            #column        Int      The column number in which it begins.
//                //            #function      String   The name of the declaration in which it appears.
//                //            #dsohandle     String   The dso handle.
//                print("\n\n\nFile -> \(#file), Function -> \(#function), Line -> \(#line)\n")
//                print("Request: \(String(describing: response.request))")   // original url request
//                print("Parameters: \(self.parameters.description)")   // original url request
//                //print("Response: \(String(describing: response.response))") // http url response
//                //print("Result: \(response.result)")                         // response serialization result
//                
//                if let data = response.data, let utf8Text = String(data: data, encoding: .utf8) {
//                    print("String Data: \(utf8Text)") // original server data as UTF8 string
//                }
//                
//                if let json = response.value {
//                    print("JSON Response : \(json)") // serialized json response
//                }
//                
//                // Hide HUD
//                //                    DispatchQueue.main.asyncAfter(deadline: .now()) {
//                // your code here
//                if Thread.isMainThread {
//                    VVSingleton.sharedInstance.hideHUD()
//                }
//                else {
//                    DispatchQueue.main.async {
//                        VVSingleton.sharedInstance.hideHUD()
//                    }
//                }
//                
//                completionHandler(response)
//            }
//        }
//    }
    
    func executeFollowUserApi(params:[String:Any], completion:@escaping (Result<FollowUserData,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.followUser.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<FollowUserData>, Error>) in
            switch result {
            case .success(let data):
                self.followUserData = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }    
}
class SelectVideoViewModel: NSObject {
    var searchUserData = [SearchuserData]()
    
    private(set) var searchUserClickData: SearchTotalData?  {
        didSet {
            self.SearchToController()
        }
    }
    
    var SearchToController : (() -> ()) = {}
    
    func executeSearchVideoApi(params: [String:Any]) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.searchVideo.path, method: .get).executeQuery {  (result: Result<WhoozaResult<SearchTotalData>, Error>) in
                switch result {
                    case .success(let data):
                    self.searchUserClickData = data.data
                    case .failure(let error):
                        print(error)
            }
        }
    }
    
//    func executeSearchVideoApi(params:[String:Any], completion:@escaping (Result<[SearchuserData],Error>) -> Void) {
//        NetworkManager(data: [:], params: params, path: WebServiceAPI.searchVideo.path, method: .post, isJSONRequest: true).executeQuery { (result:Result<WhoozaResult<[SearchuserData]>, Error>) in
//            switch result {
//            case .success(let data):
//                self.searchUserData = data.data ?? []
//                if let trucksData = data.data {
//                    completion(.success(trucksData))
//                }
//            case .failure(let error):
//                DispatchQueue.main.async {
//                    completion(.failure(error))
//                }
//            }
//        }
//    }
}
