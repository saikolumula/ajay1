//
//  ProfilePageCell.swift
//  Whoozza
//
//  Created by sainath on 11/03/22.
//

import UIKit
import AVKit

class ProfilePageCell: UICollectionViewCell {
    @IBOutlet weak var playVideoView: UIView!
    @IBOutlet weak var playVideoButton: UIButton!
    @IBOutlet weak var VideoLikesCount: UILabel!
    
    
    var playerView: PlayerVideoView = {
        var player = PlayerVideoView()
        player.backgroundColor = .cyan
        return player
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        playVideoView.addSubview(playerView)
        // we are taking care of the constraints
        playerView.translatesAutoresizingMaskIntoConstraints = false
        // pin the image to the whole collectionview - it is the same size as the container
        playerView.topAnchor.constraint(equalTo: topAnchor).isActive = true
        playerView.leftAnchor.constraint(equalTo: leftAnchor).isActive = true
        playerView.rightAnchor.constraint(equalTo: rightAnchor).isActive = true
        playerView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }

    // The AVPlayer
    var videoPlayer: AVPlayer? = nil

//    func playVideo() {
//
//        guard let path = Bundle.main.path(forResource: "AppInventorL1Setupemulator", ofType:"mp4") else {
//            debugPrint("video.m4v not found")
//            return
//        }
//        // set the video player with the path
//        videoPlayer = AVPlayer(url: URL(fileURLWithPath: path))
//        // play the video now!
//        videoPlayer?.playImmediately(atRate: 1)
//        // setup the AVPlayer as the player
//        playerView.player = videoPlayer
//    }

    func stopVideo() {
        playerView.player?.pause()
    }
    
}
