import Foundation
import Foundation
struct FollowUserData : Codable {
    let user_id : String?
    let follow_user_id : String?
    let inserted_productid : String?
    let created: String?
  
    enum CodingKeys: String, CodingKey {

        case user_id = "user_id"
        case follow_user_id = "follow_user_id"
        case inserted_productid = "inserted_productid"
        case created = "created"
    }
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        user_id = try values.decodeIfPresent(String.self, forKey: .user_id)
        follow_user_id = try values.decodeIfPresent(String.self, forKey: .follow_user_id)
        created = try values.decodeIfPresent(String.self, forKey: .created)
        inserted_productid = try values.decodeIfPresent(String.self, forKey: .inserted_productid)
    }
}
struct FollowUser : Codable {
    let success : Bool?
    let message : String?
    let data : FollowUserData?

    enum CodingKeys: String, CodingKey {

        case success = "success"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        success = try values.decodeIfPresent(Bool.self, forKey: .success)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent(FollowUserData.self, forKey: .data)
    }

}





