

import Foundation
struct SignInData : Codable {
	let user_id : String?
	let username : String?
	let password : String?
	let first_name : String?
	let last_name : String?
	let email : String?
	let mobile : String?
	let sql : String?

	enum CodingKeys: String, CodingKey {

		case user_id = "user_id"
		case username = "username"
		case password = "password"
		case first_name = "first_name"
		case last_name = "last_name"
		case email = "email"
		case mobile = "mobile"
		case sql = "sql"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		user_id = try values.decodeIfPresent(String.self, forKey: .user_id)
		username = try values.decodeIfPresent(String.self, forKey: .username)
		password = try values.decodeIfPresent(String.self, forKey: .password)
		first_name = try values.decodeIfPresent(String.self, forKey: .first_name)
		last_name = try values.decodeIfPresent(String.self, forKey: .last_name)
		email = try values.decodeIfPresent(String.self, forKey: .email)
		mobile = try values.decodeIfPresent(String.self, forKey: .mobile)
		sql = try values.decodeIfPresent(String.self, forKey: .sql)
	}

}
struct UserData : Codable {
    let success : Bool?
    let message : String?
    let data : SignInData?

    enum CodingKeys: String, CodingKey {

        case success = "success"
        case message = "message"
        case data = "data"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        success = try values.decodeIfPresent(Bool.self, forKey: .success)
        message = try values.decodeIfPresent(String.self, forKey: .message)
        data = try values.decodeIfPresent(SignInData.self, forKey: .data)
    }

}
