//
//  ColourPalette.swift
//  WhoozaNavigationController
//
//  Created by Sunith on 14/10/21.
//

import Foundation
import UIKit

enum ColorPalette {
    case primaryOrange
    case backgroundGray
    case selectedGreen
    case scheduledBackground
    case buttonDisabledBackground
    case buttonDisabledText
}

extension ColorPalette {
    var uiColor: UIColor {
        switch self {
        case .primaryOrange:
            return UIColor(named: "WhoozaPrimary") ?? .white
        case .backgroundGray:
            return UIColor(named: "backgroundPrimary") ?? .white
        case .selectedGreen:
            return UIColor(named: "green") ?? .white
        case .scheduledBackground:
            return UIColor(named: "ScheduledBackground") ?? .white
        case .buttonDisabledBackground:
            return UIColor(named: "buttonDisabled") ?? .white
        case .buttonDisabledText:
            return UIColor(named: "buttonDisabledText") ?? .gray
        }
    }
}
