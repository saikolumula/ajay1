//
//  RegistrationViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit

class RegistrationViewController: UIViewController {

    @IBOutlet weak var userNameTextfield: UITextField!
    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var continueWithGoogleView: UIView!
    @IBOutlet weak var continueWithFacebookView: UIView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        signUpButton.layer.cornerRadius = 20
        continueWithGoogleView.layer.cornerRadius = 5
        continueWithFacebookView.layer.cornerRadius = 5

        // Do any additional setup after loading the view.
    }
    
    @IBAction func continueWithGoogleAction(_ sender: Any) {
    }
    
    @IBAction func continueWithFacebookAction(_ sender: Any) {
    }
    
    @IBAction func signInAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func signUpAction(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(identifier: "LoginViewController") as! LoginViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
