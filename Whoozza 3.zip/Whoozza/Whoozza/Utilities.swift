//
//  Utilities.swift
//  Whoozza
//
//  Created by Sandip on 08/03/22.
//

import UIKit

class Utilities: NSObject {

    class func getSafeAreaTopPadding() -> CGFloat {
        var topPadding: CGFloat = 0
        if #available(iOS 11.0, *) {
            topPadding = (appDelegate.window?.safeAreaInsets.top)!
        }
        return topPadding
    }
    
    class func getSafeAreaBottomPadding() -> CGFloat {
        var bottomPadding: CGFloat = 0
        if #available(iOS 11.0, *) {
            bottomPadding = (appDelegate.window?.safeAreaInsets.bottom)!
        }
        return bottomPadding
    }
}
