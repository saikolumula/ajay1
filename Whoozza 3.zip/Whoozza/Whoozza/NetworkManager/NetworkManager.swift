//
//  TLNetworkManager.swift
//  TrukkerLoad
//
//  Created by Nandeesh on 09/10/21.
//

import Foundation
import Alamofire

class NetworkManager: NSObject {
    var parameters = Parameters()
    var headers = HTTPHeaders()
    var method: HTTPMethod!
    var url: URL!
    var encoding: ParameterEncoding = URLEncoding.default
    init(data: [String: Any], params: [String: Any], path: String, method: HTTPMethod, isJSONRequest: Bool = true) {
        super.init()
        data.forEach {parameters.updateValue($0.value, forKey: $0.key)}
        HeaderManager.shared.getHeaders().forEach({self.headers.add(name: $0.key, value: $0.value)})
        self.url = createUrl(path: path, params: params)
        if !isJSONRequest {
            encoding = JSONEncoding.default
        }
        self.method = method
        print("WebServiceAPI: \(self.url!) \n data: \(parameters)")
    }
    private func createUrl(path: String, params: [String: Any]) -> URL? {
        let urlStr = WebService.StagingServer.baseURL + "/\(path)"
        guard let url =  urlStr.url(params) else { return nil }
        return url
    }
    func executeQuery<T>(completion: @escaping (Result<TrukkerResult<T>, Error>) -> Void) where T: Codable {
        if Reach().connectionStatus() == .offline ||
           Reach().connectionStatus() == .unknown {
            return
        }
        AF.request(url, method: method, parameters: parameters, encoding: encoding, headers: headers).responseData(completionHandler: {response in
            switch response.result {
            case .success(let res):
                if let code = response.response?.statusCode {
                    switch code {
                    case 200...299:
                        do {
                            let result = try JSONDecoder().decode(TrukkerResult<T>.self, from: res)
                            if result.success {
                                completion(.success(result))
                            } else {
//                                Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: result.message ?? "")
//                                let error = NSError(domain: "", code: 401, userInfo: [ NSLocalizedDescriptionKey: result.message ?? "Something went wrong. Please try again later"])
//                                completion(.failure(error))
                            }
                        } catch let error {
                            print(String(data: res, encoding: .utf8) ?? "No response received")
                            print(error)
//                            Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: error.localizedDescription ?? "No response received")
                            completion(.failure(error))
                        }
                    case 400...499:
                        do {
                        let result = try JSONDecoder().decode(TrukkerResult<T>.self, from: res)
                        if result.success {
                            completion(.success(result))
                        } else {
//                            Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: result.message ?? "No response received")
//                            let error = NSError(domain: "", code: 401, userInfo: [ NSLocalizedDescriptionKey: result.message ?? "Something went wrong. Please try again later"])
//                            completion(.failure(error))
                        }
                        } catch let error {
                            print(String(data: res, encoding: .utf8) ?? "No response received")
                            print(error)
//                            Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: error.localizedDescription ?? "No response received")
                            completion(.failure(error))
                        }
                    case 500...599:
                        do {
                            let result = try JSONDecoder().decode(TrukkerResult<T>.self, from: res)
                            if result.success {
                                completion(.success(result))
                            } else {
//                                Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: result.message ?? "No response received")
//                                let error = NSError(domain: "", code: 401, userInfo: [ NSLocalizedDescriptionKey: result.message ?? "Something went wrong. Please try again later"])
//                                completion(.failure(error))
                            }
                        } catch let error {
                            print(String(data: res, encoding: .utf8) ?? "No response received")
                            print(error)
//                            Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: error.localizedDescription ?? "No response received")
                            completion(.failure(error))
                        }
                    default:
                        do {
                            let result = try JSONDecoder().decode(TrukkerResult<T>.self, from: res)
//                            let error = NSError(domain: "", code: result.errorCode, userInfo: [ NSLocalizedDescriptionKey: result.message ?? "Something went wrong. Please try again later"])
//                            Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: result.message ?? "No response received")
//                                completion(.failure(error))
                        } catch let error {
                            print(String(data: res, encoding: .utf8) ?? "No response received")
                            print(error)
//                            Utility.showAlertViewWithAutoDismiss(title: "Sorry!", message: error.localizedDescription ?? "No response received")
                            completion(.failure(error))
                        }
                    }
                }
            case .failure(let error):
                if let code = response.response?.statusCode {
                    switch code {
                    case 400...499:
//                        Utility.showAlertViewWithAutoDismiss(title: "", message: Constants.General.somethingWentWrong)
                        print(response.error as Any)
                        completion(.failure(error))
                    case 500...599:
//                        Utility.showAlertViewWithAutoDismiss(title: "", message: Constants.General.serverDown)
                        print(response.error as Any)
                        completion(.failure(error))
                    default:
                        print(response.error as Any)
                    }
                }
            }
        })
    }
}
