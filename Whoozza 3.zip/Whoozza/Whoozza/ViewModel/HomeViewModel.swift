//
//  File.swift
//  Whoozza
//
//  Created by sainath on 09/03/22.
//

import Foundation
class HomeViewModel{
    
    var homePageUrls = [HomeModel]()
    var likeVideoUrl:VideoLiked?
    
    func executeHomeVideoApi(params:[String:Any], completion:@escaping (Result<[HomeModel],Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.homeVideosUrl.path, method: .get, isJSONRequest: true).executeQuery { (result:Result<TrukkerResult<[HomeModel]>, Error>) in
            switch result {
            case .success(let data):
                self.homePageUrls.append(contentsOf: data.data ?? [])
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
    func executeLikeVideoApi(params:[String:Any], completion:@escaping (Result<VideoLiked,Error>) -> Void) {
        NetworkManager(data: [:], params: params, path: WebServiceAPI.videoLiked.path, method: .get, isJSONRequest: true).executeQuery { (result:Result<TrukkerResult<VideoLiked>, Error>) in
            switch result {
            case .success(let data):                
                self.likeVideoUrl = data.data
                if let trucksData = data.data {
                    completion(.success(trucksData))
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    completion(.failure(error))
                }
            }
        }
    }
}
