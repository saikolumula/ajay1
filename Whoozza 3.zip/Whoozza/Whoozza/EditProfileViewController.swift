//
//  EditProfileViewController.swift
//  Whoozza
//
//  Created by sainath on 10/03/22.
//

import UIKit

class EditProfileViewController: UIViewController {

    @IBOutlet weak var firstNameView: UIView!
    @IBOutlet weak var lastNameView: UIView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var mobileNumber: UIView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        firstNameView.layer.cornerRadius = 5
        lastNameView.layer.cornerRadius = 5
        emailView.layer.cornerRadius = 5
        mobileNumber.layer.cornerRadius = 5
        


        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func editAccountAction(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }

}
