//
//  ViewController.swift
//  Whoozza
//
//  Created by sainath on 07/03/22.
//

import Foundation
import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    @IBOutlet weak var homeCollectionView: UICollectionView!
    let repository = HomeViewModel()
    var likeID:Int = 0
    var userID:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        DispatchQueue.main.async {
            self.loadData()
            self.loadLikedData()
        }
        self.homeCollectionView.register(UINib(nibName: "HomeCell", bundle: nil), forCellWithReuseIdentifier: "HomeCell")
        
        self.homeCollectionView.delegate = self
        self.homeCollectionView.dataSource = self
        self.homeCollectionView.alwaysBounceVertical = true
        // set the background of the collection view
        self.homeCollectionView.backgroundColor = .white
    }
    let group = DispatchGroup()

    func loadData(){
        repository.executeHomeVideoApi(params: [:]){ (result: Result<[HomeModel], Error>) in
            switch result {
            case .success:
                self.homeCollectionView.reloadData()
            case .failure:
                print("error")
            }
        }
    }
    
    func loadLikedData(){
//        group.enter()
        let params:[String:Any] = ["user_id":userID,"video_id":likeID]
        repository.executeLikeVideoApi(params: params){ (result: Result<VideoLiked, Error>) in
            switch result {
            case .success:
                self.homeCollectionView.reloadData()
            case .failure:
                print("error")
            }
        }
//        group.leave()
    }
    
//    group.notify(queue: .main) {
//
//    }
    override func viewDidAppear(_ animated: Bool) {
        // call super of viewDidAppear
        super.viewDidAppear(animated)
    }
    

//    override func loadView() {
//        // set up a UICollectionViewFlowLayout
//        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
//        // with a set item size
//        layout.itemSize = CGSize(
//            width: UIScreen.main.bounds.size.width - 20,
//            height: UIScreen.main.bounds.size.width / 1)
//        // which scrolls vertically
//        layout.scrollDirection = .vertical
//        // setup the collectionview
//        homeCollectionView = UICollectionView(
//            frame: .zero,
//            collectionViewLayout: layout)
//        // set the view as the collectionView
//        self.view = homeCollectionView
//    }
        
    /// called when the user scrolls the scrollview (in this case a UICollectionView)
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // the visible cells are returned, and sorted into order
        let visibleCells = self.homeCollectionView.indexPathsForVisibleItems
            .sorted { top, bottom -> Bool in
                return top.section < bottom.section || top.row < bottom.row
            }.compactMap { indexPath -> UICollectionViewCell? in
                return self.homeCollectionView.cellForItem(at: indexPath)
            }
        // the indexpaths of the visible cells are sorted into order
        let indexPaths = self.homeCollectionView.indexPathsForVisibleItems.sorted()
        // a property containing the number of visible cells
        let cellCount = visibleCells.count
        // if we don't have a first cell, we don't have any cells and there isn't anything to do
        guard let firstCell = visibleCells.first as? HomeCell, let firstIndex = indexPaths.first else {return}
        // check if the first cell is visible
        checkVisibilityOfCell(cell: firstCell, indexPath: firstIndex)
        if cellCount == 1 {return}
        // if we don't have a last cell, there is only one so we don't have more to do
        guard let lastCell = visibleCells.last as? HomeCell, let lastIndex = indexPaths.last else {return}
        // check if the last cell is visible
        checkVisibilityOfCell(cell: lastCell, indexPath: lastIndex)
    }
    /// check the visibility of the SubclassedCollectionViewCell
    func checkVisibilityOfCell(cell: HomeCell, indexPath: IndexPath) {
        // compute the frame of the cell
        if let cellRect = (homeCollectionView.layoutAttributesForItem(at: indexPath)?.frame) {
            // it is visible iff the bounds of the cell are contained wholly in a collectionview
            let completelyVisible = homeCollectionView.bounds.contains(cellRect)
            // update the cell accordingly
            if completelyVisible {()} else {cell.stopVideo()}
        }
    }
}
extension ViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        repository.homePageUrls.count
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCell", for: indexPath) as? HomeCell {
            
            let videoURL = URL(string: repository.homePageUrls[indexPath.row].video)
            likeID = repository.homePageUrls[indexPath.row].showLikeBtn
            userID = repository.homePageUrls[indexPath.row].userID
            cell.userLIkeLabel.text = repository.homePageUrls[indexPath.row].likeCnt
            cell.userCommentedLabel.text = "\(repository.homePageUrls[indexPath.row].showLikeBtn)"
            
            let player = AVPlayer(url: videoURL!)
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = cell.playerContainerView.bounds
            cell.playerContainerView.layer.addSublayer(playerLayer)
            player.play()         
            
//            if let cellRect = (collectionView.layoutAttributesForItem(at: indexPath)?.frame) {
//                let completelyVisible = collectionView.bounds.contains(cellRect)
//                if completelyVisible {cell.playVideo()}
//            }
            
            return cell
        }
        fatalError("Could not dequeue cell")
    }
}
extension ViewController: UICollectionViewDelegateFlowLayout {

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            let width = ((collectionView.frame.width)) // 15 because of paddings
            print("cell width : \(width)")
        return CGSize(width: width, height: SCREEN_HEIGHT - Utilities.getSafeAreaTopPadding() - Utilities.getSafeAreaBottomPadding())

    }
}

